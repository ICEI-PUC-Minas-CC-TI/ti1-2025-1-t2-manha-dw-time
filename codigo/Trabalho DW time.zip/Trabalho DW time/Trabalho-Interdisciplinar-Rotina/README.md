# Trabalho-Interdisciplinar-Rotina
Repositório do Grupo 2 - Dificuldade na gestão de rotinas pessoais.

Contexto do projeto (Introdução, Problema, Objetivo do projeto, Justificativa e Público-alvo)
Especificação do Projeto (Histórias de usuários, requisitos do projeto)
Projeto de Interface (Fluxo do usuário, Wireframes das telas, Protótipo Interativo [LINK])
Metodologia (Organização da equipe e divisão de papéis, Quadro de controle de tarefas - Kanban) 
Referências Bibliográficas

A ser editado.
